package com.example.kiemtragiuaky;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btPlay;
    TextView tvScore;
    TextView tvLevel;
    TextView tvNOP;
    ImageView imgViews[][] = new ImageView[6][6];
    int imgChoosen[][] = new int[6][6];

    int nop;
    int score;
    int level;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myInit();

        btPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btPlay.setEnabled(false);
                runNewLevel();
            }
        });

        chooseTiles();
    }

    private void runNewLevel() {
        resetOpenedTiles();
        generateOpenedTiles();
        hideOpenedTiles();
        CountDownTimer countDownTimer = new CountDownTimer(3000,300) {
            boolean zzz = false;
            @Override
            public void onTick(long millisUntilFinished) {
                if(millisUntilFinished > 0 && zzz == false) {
                    showOpenedTiles();
                    zzz = true;
                    disableImgViews();
                }
            }

            @Override
            public void onFinish() {
                hideOpenedTiles();
                enableImgViews();
            }
        };
        countDownTimer.start();
    }

    private void myInit() {
        mapping();
        nop = 3;
        score = 0;
        level = 1;

        tvNOP.setText("Turn remaining " + nop);
        tvScore.setText("Score " + score);
        tvLevel.setText("Level " + level);

        resetOpenedTiles();
        hideOpenedTiles();
        disableImgViews();
        btPlay.setEnabled(true);
    }

    private void resetOpenedTiles() {
        for(int ii = 0; ii < 6; ii++) {
            for(int jj = 0; jj < 6; jj++) {
                imgChoosen[ii][jj] = 0;
            }
        }
    }

    private void generateOpenedTiles() {
        int zUperbound = 2;
        Random rd = new Random();
        int numOfOpenedTiles = level + 2;

        while(numOfOpenedTiles > 0) {
            Random mrd = new Random();
            int zz = mrd.nextInt(35);
            int vv = rd.nextInt(zUperbound);

            if(vv > 0) {
                if(imgChoosen[zz / 6][zz % 6] != 1) {
                    imgChoosen[zz / 6][zz % 6] = 1;
                    numOfOpenedTiles--;
                }
            }
        }
    }

    private void showOpenedTiles() {
        for(int ii = 0; ii < 6; ii++) {
            for(int jj = 0; jj < 6; jj++) {
//                if(imgChoosen[ii][jj] != 0) {
//                    imgViews[ii][jj].setImageResource(R.drawable.cathigh);
//                }
                showOpenOneTile(ii, jj);
            }
        }
    }

    private void showOpenOneTile(int ii, int jj) {
        if(imgChoosen[ii][jj] != 0) {
            imgViews[ii][jj].setImageResource(R.drawable.cathigh);
        }
    }

    private void hideOpenedTiles() {
        for(int ii = 0; ii < 6; ii++) {
            for(int jj = 0; jj < 6; jj++) {
                imgViews[ii][jj].setImageResource(R.drawable.tile);
            }
        }
    }

    private void nextLevel() {
        addBonus();
        level++;
        tvLevel.setText("Level " + level);
        Toast.makeText(this, "Next level!", Toast.LENGTH_SHORT).show();
        runNewLevel();
    }

    private void lostLevel() {
        if(nop > 1) {
            nop--;
            tvNOP.setText("Turn remaining " + nop);
            if(level > 1) {
                level--;
                tvLevel.setText("Level " + level);
            }
            runNewLevel();
        } else {
            Toast.makeText(this, "Game Over!", Toast.LENGTH_SHORT).show();
            myInit();
        }
    }

    private void addBonus() {
        // bonus = 2 * level
        score += level * 2;
        tvScore.setText("Score " + score);
    }

    private void addScore() {
        // add 1 score as true choice
        score ++;
        tvScore.setText("Score " + score);
    }

    // Set Enable Img View
    private void enableImgViews() {
        for(int ii = 0; ii < 6; ii++) {
            for(int jj = 0; jj < 6; jj++) {
                imgViews[ii][jj].setEnabled(true);
            }
        }
    }

    private void disableImgViews() {
        for(int ii = 0; ii < 6; ii++) {
            for(int jj = 0; jj < 6; jj++) {
                imgViews[ii][jj].setEnabled(false);
            }
        }
    }

    int currentch = 0;
    // choose imgview (tile)
    private void chooseTiles() {
        currentch = level + 2;
        for(int ii = 0; ii < 6; ii++) {
            for(int jj = 0; jj < 6; jj++) {
                int finalIi = ii;
                int finalJj = jj;
                imgViews[ii][jj].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(imgChoosen[finalIi][finalJj] == 1) {
//                            numOfTiles[0]--;
                            currentch--;
                            showOpenOneTile(finalIi, finalJj);
                            Toast.makeText(MainActivity.this, "Right", Toast.LENGTH_SHORT).show();
                            addScore();
                            if(currentch == 0) {
                                nextLevel();
                                currentch = level + 2;
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "Wrong!", Toast.LENGTH_SHORT).show();
                            lostLevel();
                            currentch = level + 2;
                        }
                    }
                });
            }
        }
    }

    private void mapping() {
        imgViews[0][0] = (ImageView) findViewById(R.id.imageView00);
        imgViews[0][1] = (ImageView) findViewById(R.id.imageView01);
        imgViews[0][2] = (ImageView) findViewById(R.id.imageView02);
        imgViews[0][3] = (ImageView) findViewById(R.id.imageView03);
        imgViews[0][4] = (ImageView) findViewById(R.id.imageView04);
        imgViews[0][5] = (ImageView) findViewById(R.id.imageView05);

        imgViews[1][0] = (ImageView) findViewById(R.id.imageView10);
        imgViews[1][1] = (ImageView) findViewById(R.id.imageView11);
        imgViews[1][2] = (ImageView) findViewById(R.id.imageView12);
        imgViews[1][3] = (ImageView) findViewById(R.id.imageView13);
        imgViews[1][4] = (ImageView) findViewById(R.id.imageView14);
        imgViews[1][5] = (ImageView) findViewById(R.id.imageView15);

        imgViews[2][0] = (ImageView) findViewById(R.id.imageView20);
        imgViews[2][1] = (ImageView) findViewById(R.id.imageView21);
        imgViews[2][2] = (ImageView) findViewById(R.id.imageView22);
        imgViews[2][3] = (ImageView) findViewById(R.id.imageView23);
        imgViews[2][4] = (ImageView) findViewById(R.id.imageView24);
        imgViews[2][5] = (ImageView) findViewById(R.id.imageView25);

        imgViews[3][0] = (ImageView) findViewById(R.id.imageView30);
        imgViews[3][1] = (ImageView) findViewById(R.id.imageView31);
        imgViews[3][2] = (ImageView) findViewById(R.id.imageView32);
        imgViews[3][3] = (ImageView) findViewById(R.id.imageView33);
        imgViews[3][4] = (ImageView) findViewById(R.id.imageView34);
        imgViews[3][5] = (ImageView) findViewById(R.id.imageView35);

        imgViews[4][0] = (ImageView) findViewById(R.id.imageView40);
        imgViews[4][1] = (ImageView) findViewById(R.id.imageView41);
        imgViews[4][2] = (ImageView) findViewById(R.id.imageView42);
        imgViews[4][3] = (ImageView) findViewById(R.id.imageView43);
        imgViews[4][4] = (ImageView) findViewById(R.id.imageView44);
        imgViews[4][5] = (ImageView) findViewById(R.id.imageView45);

        imgViews[5][0] = (ImageView) findViewById(R.id.imageView50);
        imgViews[5][1] = (ImageView) findViewById(R.id.imageView51);
        imgViews[5][2] = (ImageView) findViewById(R.id.imageView52);
        imgViews[5][3] = (ImageView) findViewById(R.id.imageView53);
        imgViews[5][4] = (ImageView) findViewById(R.id.imageView54);
        imgViews[5][5] = (ImageView) findViewById(R.id.imageView55);

        tvScore = (TextView) findViewById(R.id.textViewScore);
        tvLevel = (TextView) findViewById(R.id.textViewLevel);
        tvNOP = (TextView) findViewById(R.id.textViewNOP);

        btPlay = (Button) findViewById(R.id.buttonPlay);
    }
}